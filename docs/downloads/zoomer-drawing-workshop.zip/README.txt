Zoomer drawing workshop

This package contains the local drawing editor, MuJoCo simulation, training
code, saved 19-stroke target and evaluated residual PPO policy.

From the extracted folder, run:
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python app/server.py

Open http://127.0.0.1:8765 in a browser. Import a target exported from the
Zoomer3D website, save it, select a training budget, then choose Train this
drawing. Target files stay in targets/ and training runs stay in training/.
Only one training job runs at a time.

To evaluate the supplied saved policy on the recorded target:
.venv/bin/python simulation/run_workshop.py --drawing targets/3201207f878b4707ab8753bffb68dbac.json --policy training/zoomer_readable/policy.zip --output training/repeated_trace.json

See simulation/TRAINING.md for the curriculum, contact rules, measurements
and simulation assumptions. The system combines programmed task sequencing,
inverse kinematics and torque feedback with seven learned PPO corrections.
The printed display model has no powered drive or drawing hardware.

The video and Blender model are separate downloads on the website. This
package includes the files needed for the drawing and training app. Video
recording and geometry-rebuild helpers are not included.
