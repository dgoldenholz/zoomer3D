Zoomer3D print files

Start with PRINTING.html for settings, orientation and assembly instructions.
The guide opens in a browser and can be printed.

body/ contains the Prusa XL fit-coupon and body 3MF projects.
The baseline body uses four perimeters and 20% gyroid infill.
The optional five-color v2 uses two perimeters and 10% grid infill.
Recheck its saved filament colors and profiles before printing.

covers/ contains the successful faceted PETG cover, its flat-wall test,
matching cap and adapter, the clear-sheet alternative and cutting template,
and the earlier supported dome and curved vase cover.

For the faceted cover shown in the photos, use
covers/02_XL_faceted_shell_VASE.3mf in vase mode and
covers/03_XL_shared_cap_and_adapter_NORMAL.3mf in normal mode.
Open 3MF files as PrusaSlicer projects to load the embedded settings.
They target the Original Prusa XL, five tools, 0.4 mm nozzles.
Keep 100% scale and the supplied orientations. Match profiles to your spools.

STL/body/ contains print-oriented part meshes.
STL/body-colors/ contains the separated color meshes.
STL/faceted-and-sheet/ and STL/curved-vase/ contain cover print inputs.
Vase STL inputs are intentionally solid outer shapes. The slicer creates
the single wall. Check for no floor, roof, infill or supports in the shell.
Print caps, adapters and retainers in separate normal-mode jobs.

To match the photos, use tool 1 for metallic silver, 2 for red, 3 for blue,
4 for green and 5 for dark gray. The project labels the silver body parts
"ivory" and saves an ivory preview color. Load your silver filament and
select its matching profile before slicing.
Use clear PETG in tool 1 on the separate cover plates.
No G-code is included. Slice for your actual printer and loaded filament.
No screws or metal hardware are required. Keep moving bearings free of glue.

The successful cover is transparent enough to see the head, but printed PETG
still has layer lines. Test clarity with your material before assembly.
The sheet-window alternative uses a separate flat 0.50 mm PETG sheet.

FILES.json records the SHA-256 hashes of the supplied project and STL files.
